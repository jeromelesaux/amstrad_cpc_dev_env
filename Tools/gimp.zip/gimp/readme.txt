Installation instructions:

1. Copy CPCpalette into your local .gimp-2.2/palettes directory.

(windows version: C:\Documents and Settings\<username>\.gimp-2.2\palettes)

2. Open your local templaterc from your local .gimp-2.2 directory.

(windows version: C:\Documents and Settings\<username>\.gimp-2.2\templaterc)

And append the contents of the CPCtemplate file to it.

When you run GIMP you can now choose the CPC palette, and you can choose to create images 
for the Amstrad CPC. For best results create an image, right click and choose 'Dot for Dot' 
to see the pixels as they would look on the CPC.
